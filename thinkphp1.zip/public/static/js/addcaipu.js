

function moveUp(_3) {
	var _1 = _3.parentNode.parentNode;
	var _0 = _1.previousSibling;
	while (_0 && _0.nodeType != 1) {
		_0 = _0.previousSibling
	}
	if (_0) {
		swapNode(_1, _0)
	}
}
function moveDown(_3) {
	var _1 = _3.parentNode.parentNode;
	var _0 = _1.nextSibling;
	while (_0 && _0.nodeType != 1) {
		_0 = _0.nextSibling
	}
	if (_0) {
		swapNode(_1, _0)
	}
}
function swapNode(node1, node2) {
	var _2 = node1.parentNode;
	var _4 = node1.nextSibling;
	var _5 = node2.nextSibling;
	if (_4) _2.insertBefore(node2, _4);
	else _2.appendChild(node2);
	if (_5) _2.insertBefore(node1, _5);
	else _2.appendChild(node1)
}
function change(picId, fileId) {
	var pic = document.getElementById(picId);
	var file = document.getElementById(fileId);
	
	if(fileId!="titlepicfile"){
$.ajaxFileUpload
(
  {
 url:'doajaxfileupload.php', //你处理上传文件的服务端
 secureuri:false,
 fileElementId:fileId,
 dataType: 'text',
 success: function (data)
 {
	// alert(data);
 $("#mbig"+picId).val(data);
 // $("#mmbig"+picId).val(data);
// $("#"+fileId).remove();
 }
 }
 )
	}
	
	
	if (window.FileReader) {
		oFReader = new FileReader();
		oFReader.readAsDataURL(file.files[0]);
		oFReader.onload = function(oFREvent) {
			pic.src = oFREvent.target.result
		}
	} else if (document.all) {
		file.select();
		
		
		
		var reallocalpath = document.selection.createRange().text;
		pic.style.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod='scale',sizingMethod='image',src=\"" + reallocalpath + "\")";
		pic.src = 'data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=='
	} else if (file.files) {
		if (file.files.item(0)) {
			url = file.files.item(0).getAsDataURL();
			pic.src = url
		}
	}
}
function checkform(form) {
	if (document.getElementById("title").value == "") {
		alert("菜谱名称必须填");
		return false
	}
	if (document.getElementById("titlepicfile").value == "" && document.getElementById("titlepic").value == "") {
		alert("请上传菜谱成品图");
		return false
	}
	if (document.getElementById("prnd").value == "") {
		alert("请选择烹饪难度");
		return false
	}
	if (document.getElementById("prtime").value == "") {
		alert("请选择烹饪时间");
		return false
	}
	if (document.getElementById("classify").value == "") {
		alert("请选择分类");
		return false
	}
	if (document.getElementById("classifyer").value == "") {
		alert("请选择详细分类");
		return false
	}
	if (document.getElementById("story").value == "") {
		alert("请填写这道菜背后的故事");
		return false
	}
	var zlinputs = document.getElementById('zhuliao').getElementsByTagName('input');
	var zlval = '';
	for (var i = 0, ii = zlinputs.length; i < ii; i++) {
		zlval += zlinputs[i].value
	}
	if (zlval == "") {
		alert("主料名称用量必须填");
		return false
	}
	var flinputs = document.getElementById('fuliao').getElementsByTagName('input');
	var flval = '';
	for (var i = 0, ii = flinputs.length; i < ii; i++) {
		flval += flinputs[i].value
	}
	if (flval == "") {
		alert("辅料名称用量必须填");
		return false
	}
	for (i = 0; i < zhuliao.rows.length; i++) {
		Names1 = zhuliao.rows[i].cells[0].getElementsByTagName("input")[0].value;
		Names2 = zhuliao.rows[i].cells[0].getElementsByTagName("input")[1].value;
		if (Names1 == "" && Names2 !== "") {
			alert("主料名称必须填");
			return false
		}
		if (Names1 !== "" && Names2 == "") {
			alert("主料用量必须有");
			return false
		}
	}
	for (i = 0; i < fuliao.rows.length; i++) {
		Names1 = fuliao.rows[i].cells[0].getElementsByTagName("input")[0].value;
		Names2 = fuliao.rows[i].cells[0].getElementsByTagName("input")[1].value;
		if (Names1 == "" && Names2 !== "") {
			alert("辅料名称必须填");
			return false
		}
		if (Names1 !== "" && Names2 == "") {
			alert("辅料用量必须有");
			return false
		}
	}
	var bzinput1 = document.getElementsByName("mbigbuzhoupic[]");
	var bzinput2 = document.getElementsByName("mbigbuzhoupfile[]");
	var bzinput3 = document.getElementsByName("mbuzhoupicname[]");
	var bzval1 = '';
	for (var i = 0, ii = bzinput1.length; i < ii; i++) {
		bzval1 += bzinput1[i].value
	}
	var bzval2 = '';
	for (var j = 0, jj = bzinput2.length; j < jj; j++) {
		bzval2 += bzinput2[j].value
	}
	var bzval3 = '';
	for (var n = 0, nn = bzinput3.length; n < nn; n++) {
		bzval3 += bzinput3[n].value
	}
	if (bzval1 == "" && bzval2 == "" && bzval3 == "") {
		alert("做法步骤必须有");
		return false
	}
	if (document.getElementById("trick").value == "") {
		alert("请填写小窍门");
		return false
	}
	var array = document.getElementsByName("bf_type");
	var times = document.getElementById("link").value;
	for (var i = 0; i < array.length; i++) {
		if (array[i].value == "2" && array[i].checked == true) {
			if (times == null || times == "") {
				alert("请填写转载作品的链接地址");
				return false
			}
		}
	}
	alert("这是一个演示页面，您无需提交！");
	return false
}
$(function() {
	var value1 = $('input:radio[value=2]:checked').val();
	if (value1 != null) {
		$('.link').show()
	}
});